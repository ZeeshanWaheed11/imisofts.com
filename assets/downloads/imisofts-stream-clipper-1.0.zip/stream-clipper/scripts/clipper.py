#!/usr/bin/env python3
"""imisofts Stream Clipper: turn a long stream into vertical, captioned clips.

Free tool by imisofts (https://imisofts.com). MIT licence.

Commands
  setup                          check ffmpeg and install the Python packages it needs
  find "<search words>"          list recent long streams on YouTube (titles and links only)
  analyze <link-or-file> --work <folder>
                                 grab the sound, find the loud parts and chat spikes,
                                 write down what was said around them (Whisper, on this
                                 computer), and save the best candidate moments
  render --work <folder> --picks <picks.json>
                                 cut each picked moment into a 1080x1920 clip with the
                                 facecam on top, gameplay below, word-by-word captions
                                 and a title, and write the post text for every clip

Only clip streams you are allowed to clip (a streamer's clipping program, or written
permission). The tool asks for that before it starts.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
FONTS = os.path.join(ROOT, 'assets', 'fonts')
FONT_NAME = 'Inter ExtraBold'
W, H = 1080, 1920          # output size (vertical)
TOP_H = 700                # facecam band height in the facecam layout
HYPE = ['oh my god', 'no way', 'what the', 'let\'s go', 'lets go', 'bro', 'yo', 'wait', 'run', 'holy',
        'are you serious', 'what', 'no no', 'help', 'oh no', 'dude', 'insane', 'crazy', 'why']


# ---------------------------------------------------------------- helpers
def log(msg):
    print('[clipper] ' + msg, flush=True)


def run(cmd, **kw):
    return subprocess.run(cmd, check=True, **kw)


def is_url(s):
    return s.startswith('http://') or s.startswith('https://')


def hhmmss(t):
    t = int(round(t))
    return '%d:%02d:%02d' % (t // 3600, t % 3600 // 60, t % 60)


def need_ffmpeg():
    missing = [b for b in ('ffmpeg', 'ffprobe') if not shutil.which(b)]
    if missing:
        log('ffmpeg is missing. Install it, then run this again:')
        log('  Mac:     brew install ffmpeg   (Homebrew: https://brew.sh)')
        log('  Windows: winget install Gyan.FFmpeg')
        log('  Linux:   sudo apt install ffmpeg')
        sys.exit(2)


def probe_duration(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', path],
                         capture_output=True, text=True).stdout.strip()
    try:
        return float(out)
    except ValueError:
        return 0.0


def probe_size(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries',
                          'stream=width,height', '-of', 'csv=p=0:s=x', path],
                         capture_output=True, text=True).stdout.strip()
    w, h = out.split('x')[:2]
    return int(w), int(h)


# ---------------------------------------------------------------- setup
PKGS = [('yt_dlp', 'yt-dlp'), ('faster_whisper', 'faster-whisper'), ('cv2', 'opencv-python-headless<5'),
        ('numpy', 'numpy')]


def cmd_setup(_args):
    need_ffmpeg()
    log('ffmpeg found.')
    missing = []
    for mod, pkg in PKGS:
        try:
            __import__(mod)
        except Exception:
            missing.append(pkg)
    if not missing:
        log('All Python packages are installed. Ready.')
        return
    log('Installing: ' + ', '.join(missing))
    base = [sys.executable, '-m', 'pip', 'install', '--upgrade'] + missing
    r = subprocess.run(base, capture_output=True, text=True)
    if r.returncode != 0 and 'externally-managed' in (r.stderr + r.stdout):
        r = subprocess.run(base + ['--user', '--break-system-packages'], capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
        log('Install failed. Try: python3 -m pip install ' + ' '.join(missing))
        sys.exit(3)
    log('Installed. Ready.')


# ---------------------------------------------------------------- find
UPLOAD_FILTER = {'today': 'EgIIAg%3D%3D', 'week': 'EgIIAw%3D%3D', 'month': 'EgIIBA%3D%3D'}


def cmd_find(args):
    import yt_dlp
    from urllib.parse import quote_plus
    n = args.max
    opts = {'quiet': True, 'skip_download': True, 'extract_flat': 'in_playlist', 'noprogress': True,
            'playlistend': n * 4}
    tries = []
    if args.when in UPLOAD_FILTER:
        tries.append('https://www.youtube.com/results?search_query=%s&sp=%s' % (quote_plus(args.query), UPLOAD_FILTER[args.when]))
    tries.append('ytsearch%d:%s' % (n * 4, args.query))
    info, last_err = None, None
    for target in tries:
        try:
            with yt_dlp.YoutubeDL(opts) as y:
                info = y.extract_info(target, download=False)
            if info and info.get('entries'):
                break
        except Exception as e:  # YouTube sometimes refuses automated searches
            last_err = e
            info = None
    if not info:
        log('YouTube did not answer the search (%s). Paste a stream link instead.' % (str(last_err)[:120] if last_err else 'no results'))
        sys.exit(4)
    rows = []
    for e in list(info.get('entries') or [])[:n * 4]:
        dur = e.get('duration') or 0
        if dur and dur < args.min_minutes * 60:
            continue
        vid = e.get('id')
        rows.append({'title': e.get('title'), 'channel': e.get('channel') or e.get('uploader'),
                     'url': e.get('url') if is_url(e.get('url') or '') else 'https://www.youtube.com/watch?v=%s' % vid,
                     'minutes': round(dur / 60) if dur else None, 'views': e.get('view_count'),
                     'live_status': e.get('live_status')})
    rows.sort(key=lambda r: r['views'] or 0, reverse=True)
    rows = rows[:n]
    for i, r in enumerate(rows, 1):
        print('%2d. %s | %s | %s min | %s views | %s' % (i, r['title'], r['channel'], r['minutes'], r['views'], r['url']))
    if args.json:
        with open(args.json, 'w') as f:
            json.dump(rows, f, indent=1)


# ---------------------------------------------------------------- analyze
def fetch_audio(src, work):
    if is_url(src):
        import yt_dlp
        opts = {'format': 'bestaudio/best', 'outtmpl': os.path.join(work, 'source_audio.%(ext)s'),
                'quiet': True, 'noprogress': True}
        with yt_dlp.YoutubeDL(opts) as y:
            info = y.extract_info(src, download=True)
            path = y.prepare_filename(info)
        meta = {'title': info.get('title'), 'channel': info.get('channel') or info.get('uploader'),
                'url': info.get('webpage_url') or src, 'duration': info.get('duration'), 'source': src}
    else:
        path = os.path.abspath(src)
        meta = {'title': os.path.basename(src), 'channel': None, 'url': path, 'duration': None, 'source': path}
    meta['audio_path'] = path
    meta['duration'] = meta.get('duration') or probe_duration(path)
    return path, meta


def loudness_per_second(path, rate=4000):
    """Average loudness (dB) for every second of audio, streamed through ffmpeg."""
    import numpy as np
    p = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', path, '-vn', '-ac', '1', '-ar', str(rate), '-f', 's16le', '-'],
                         stdout=subprocess.PIPE)
    out, chunk = [], rate * 2
    buf = b''
    while True:
        data = p.stdout.read(chunk * 60)
        if not data:
            break
        buf += data
        while len(buf) >= chunk:
            a = np.frombuffer(buf[:chunk], dtype=np.int16).astype(np.float32) / 32768.0
            buf = buf[chunk:]
            out.append(20 * np.log10(np.sqrt(np.mean(a * a)) + 1e-6))
    p.wait()
    return np.array(out, dtype=np.float32)


def robust_z(x):
    import numpy as np
    med = np.median(x)
    mad = np.median(np.abs(x - med)) * 1.4826 + 1e-6
    return (x - med) / mad


def audio_peaks(db, keep, min_gap=None):
    import numpy as np
    n = len(db)
    if n < 10:
        return [], np.zeros(n)
    k = 3
    smooth = np.convolve(db, np.ones(k) / k, mode='same')
    win = min(301, n if n % 2 else n - 1)
    half = win // 2
    padded = np.pad(smooth, half, mode='edge')
    try:
        view = np.lib.stride_tricks.sliding_window_view(padded, win)
        base = np.median(view, axis=1)[:n]
    except Exception:
        base = np.full(n, np.median(smooth))
    z = robust_z(smooth - base)
    if min_gap is None:
        min_gap = int(max(20, min(45, n / 10)))   # short videos get closer moments, long streams stay spread out
    order = np.argsort(-z)
    chosen = []
    for i in order:
        if z[i] < 0.5 or len(chosen) >= keep:
            break
        if all(abs(int(i) - c) >= min_gap for c in chosen):
            chosen.append(int(i))
    return chosen, z


def chat_counts(src, work, duration):
    """Messages per second from a chat replay, when the platform keeps one. Returns None if not available."""
    import numpy as np
    if not is_url(src):
        return None
    try:
        import yt_dlp
        opts = {'skip_download': True, 'writesubtitles': True, 'subtitleslangs': ['live_chat', 'rechat'],
                'outtmpl': os.path.join(work, 'chat.%(ext)s'), 'quiet': True, 'noprogress': True}
        with yt_dlp.YoutubeDL(opts) as y:
            y.extract_info(src, download=True)
    except Exception as e:
        log('No chat replay (%s).' % str(e)[:80])
        return None
    files = [f for f in os.listdir(work) if f.startswith('chat.') and f.endswith('.json')]
    if not files:
        log('No chat replay for this stream.')
        return None
    counts = np.zeros(int(duration) + 1, dtype=np.float32)
    total = 0
    for fn in files:
        with open(os.path.join(work, fn), encoding='utf-8', errors='ignore') as f:
            text = f.read()
        offs = [int(m) / 1000.0 for m in re.findall(r'"videoOffsetTimeMsec"\s*:\s*"?(\d+)', text)]
        offs += [float(m) for m in re.findall(r'"content_offset_seconds"\s*:\s*([\d.]+)', text)]
        for t in offs:
            if 0 <= t <= duration:
                counts[int(t)] += 1
                total += 1
    log('Chat replay: %d messages.' % total)
    return counts if total else None


def transcribe(model, wav_path, offset=0.0):
    segs, _ = model.transcribe(wav_path, word_timestamps=True, vad_filter=True)
    text, words = [], []
    for s in segs:
        text.append(s.text.strip())
        for w in (s.words or []):
            words.append({'w': w.word.strip(), 's': round(offset + w.start, 2), 'e': round(offset + w.end, 2)})
    return ' '.join(text).strip(), words


def load_whisper(size):
    from faster_whisper import WhisperModel
    try:
        return WhisperModel(size, device='auto', compute_type='int8')
    except Exception:
        return WhisperModel(size, device='cpu', compute_type='int8')


def cmd_analyze(args):
    import numpy as np
    need_ffmpeg()
    t0 = time.time()
    work = os.path.abspath(args.work)
    os.makedirs(work, exist_ok=True)
    log('Step 1: grabbing the sound only (much smaller than the video)...')
    audio, meta = fetch_audio(args.source, work)
    dur = meta['duration']
    timings = {'sound': round(time.time() - t0, 1)}
    log('  %s, %s long (%.0f s).' % (meta.get('title'), hhmmss(dur), timings['sound']))

    log('Step 2: listening for the loud parts...')
    t1 = time.time()
    db = loudness_per_second(audio)
    peaks, z = audio_peaks(db, keep=args.windows)
    timings['loud'] = round(time.time() - t1, 1)
    log('  %d loud moments found (%.0f s).' % (len(peaks), timings['loud']))

    chat = chat_counts(args.source, work, dur)
    chat_z = None
    if chat is not None:
        c10 = np.convolve(chat, np.ones(10), mode='same')
        chat_z = robust_z(c10)
        for i in np.argsort(-chat_z)[:args.windows]:
            i = int(i)
            if chat_z[i] > 3 and all(abs(i - p) > 30 for p in peaks):
                peaks.append(i)
        log('  Checked where chat jumped.')

    log('Step 3: writing down what was said around those moments (Whisper, on this computer)...')
    t2 = time.time()
    model = load_whisper(args.model)
    timings['model'] = round(time.time() - t2, 1)
    log('  Whisper model ready (%.0f s; the very first run also downloads it once).' % timings['model'])
    t3 = time.time()
    cands = []
    for k, p in enumerate(sorted(peaks)):
        ws, we = max(0, p - args.before), min(dur, p + args.after)
        wav = os.path.join(work, 'win_%04d.wav' % k)
        run(['ffmpeg', '-y', '-v', 'error', '-ss', '%.2f' % ws, '-t', '%.2f' % (we - ws), '-i', audio,
             '-vn', '-ac', '1', '-ar', '16000', wav])
        text, words = transcribe(model, wav, offset=ws)
        os.remove(wav)
        low = ' ' + text.lower() + ' '
        bonus = min(1.5, 0.3 * sum(low.count(' ' + h) for h in HYPE))
        az = float(z[p]) if p < len(z) else 0.0
        cz = float(max(chat_z[max(0, p - 30):p + 10])) if chat_z is not None else 0.0
        cands.append({'id': 'c%02d' % (k + 1), 'peak': round(float(p), 1), 'window_start': round(ws, 1),
                      'window_end': round(we, 1), 'loud_score': round(az, 2), 'chat_score': round(cz, 2),
                      'score': round(az + 0.8 * max(cz, 0) + bonus, 2), 'text': text, 'words': words})
        log('  %s at %s, score %.1f' % (cands[-1]['id'], hhmmss(p), cands[-1]['score']))
    timings['words'] = round(time.time() - t3, 1)
    log('  Wrote down %d moments (%.0f s).' % (len(cands), timings['words']))
    cands.sort(key=lambda c: -c['score'])
    out = {'meta': meta, 'candidates': cands, 'analysis_seconds': round(time.time() - t0), 'timings': timings}
    with open(os.path.join(work, 'candidates.json'), 'w') as f:
        json.dump(out, f, indent=1)
    with open(os.path.join(work, 'candidates.md'), 'w') as f:
        f.write('# Candidate moments: %s\n\nSource: %s\nLength: %s\n\n' % (meta.get('title'), meta.get('url'), hhmmss(dur)))
        for c in cands:
            f.write('## %s | peak %s | window %s to %s | score %.1f (loud %.1f, chat %.1f)\n\n%s\n\n' % (
                c['id'], hhmmss(c['peak']), hhmmss(c['window_start']), hhmmss(c['window_end']),
                c['score'], c['loud_score'], c['chat_score'], c['text'] or '(no speech)'))
    log('Step 4: done in %d s. Read %s and pick the best moments.' % (out['analysis_seconds'],
                                                                         os.path.join(work, 'candidates.md')))


# ---------------------------------------------------------------- render
def fetch_section(meta, start, end, path_out):
    src = meta['source']
    if is_url(src):
        import yt_dlp
        from yt_dlp.utils import download_range_func
        base = path_out[:-4]
        opts = {'format': 'bv*[height<=1080]+ba/b[height<=1080]/b', 'outtmpl': base + '.%(ext)s',
                'download_ranges': download_range_func(None, [(start, end)]), 'force_keyframes_at_cuts': True,
                'merge_output_format': 'mp4', 'quiet': True, 'noprogress': True}
        with yt_dlp.YoutubeDL(opts) as y:
            y.extract_info(src, download=True)
        got = [f for f in os.listdir(os.path.dirname(path_out)) if f.startswith(os.path.basename(base) + '.')]
        os.replace(os.path.join(os.path.dirname(path_out), got[0]), path_out)
    else:
        run(['ffmpeg', '-y', '-v', 'error', '-ss', '%.2f' % start, '-i', src, '-t', '%.2f' % (end - start),
             '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-c:a', 'aac', '-b:a', '192k', path_out])


def detect_facecam(video, sw, sh, check_jpg):
    """Find a webcam overlay by looking for a face that stays in the same place. Returns (x, y, w, h) or None."""
    import cv2
    import numpy as np
    base = getattr(getattr(cv2, 'data', None), 'haarcascades', '') or ''
    xml = os.path.join(base, 'haarcascade_frontalface_default.xml')
    if not hasattr(cv2, 'CascadeClassifier') or not os.path.exists(xml):
        log('  Face model not found in this OpenCV version, skipping facecam search (pass --facecam x,y,w,h).')
        return None
    det = cv2.CascadeClassifier(xml)
    cap = cv2.VideoCapture(video)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    hits, frames = [], []
    for k in range(12):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(total * (k + 0.5) / 12))
        ok, fr = cap.read()
        if not ok:
            continue
        frames.append(fr)
        g = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
        for (x, y, w, h) in det.detectMultiScale(g, 1.1, 6, minSize=(int(sh * 0.05), int(sh * 0.05))):
            hits.append((x + w / 2, y + h / 2, w, h))
    cap.release()
    if not frames or not hits:
        return None
    best, best_n = None, 0
    for cx, cy, w, h in hits:
        group = [hh for hh in hits if abs(hh[0] - cx) < sw * 0.06 and abs(hh[1] - cy) < sh * 0.08]
        if len(group) > best_n:
            best_n, best = len(group), group
    if best_n < max(3, len(frames) * 0.4):
        return None
    cx = float(np.median([b[0] for b in best]))
    cy = float(np.median([b[1] for b in best]))
    fw = float(np.median([b[2] for b in best]))
    bw = min(sw, fw * 3.2)
    bh = min(sh, bw * 9 / 16 * 1.15)
    x = max(0, min(sw - bw, cx - bw / 2))
    y = max(0, min(sh - bh, cy - bh * 0.45))
    if x < sw * 0.06:
        x = 0
    if sw - (x + bw) < sw * 0.06:
        x = sw - bw
    if y < sh * 0.06:
        y = 0
    if sh - (y + bh) < sh * 0.06:
        y = sh - bh
    box = (int(x), int(y), int(bw), int(bh))
    img = frames[len(frames) // 2].copy()
    cv2.rectangle(img, (box[0], box[1]), (box[0] + box[2], box[1] + box[3]), (60, 220, 60), 6)
    cv2.imwrite(check_jpg, img)
    return box


def ass_time(t):
    t = max(0.0, t)
    return '%d:%02d:%02d.%02d' % (int(t // 3600), int(t % 3600 // 60), int(t % 60), int(round((t - int(t)) * 100)) % 100)


def ass_escape(s):
    return s.replace('\\', '').replace('{', '(').replace('}', ')')


def build_ass(words, title, layout, path, clip_len):
    cap_y = 1480 if layout == 'facecam' else 1500
    title_y = TOP_H if layout == 'facecam' else 330
    head = ('[Script Info]\nScriptType: v4.00+\nPlayResX: %d\nPlayResY: %d\nWrapStyle: 0\n\n'
            '[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, '
            'Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, '
            'Alignment, MarginL, MarginR, MarginV, Encoding\n'
            'Style: Cap,%s,84,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,1,0,0,0,100,100,0,0,1,7,3,5,60,60,0,1\n'
            'Style: Title,%s,58,&H00FFFFFF,&H00FFFFFF,&H0012121A,&H0012121A,1,0,0,0,100,100,0,0,3,18,0,5,60,60,0,1\n\n'
            '[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n') % (
        W, H, FONT_NAME, FONT_NAME)
    ev = []
    if title:
        ev.append('Dialogue: 1,%s,%s,Title,,0,0,0,,{\\pos(%d,%d)}%s' % (ass_time(0), ass_time(clip_len), W // 2, title_y,
                                                                       ass_escape(title.upper())))
    # captions: chunks of up to 3 words, the word being spoken in yellow
    chunks, cur = [], []
    for w in words:
        if cur and (len(cur) >= 3 or w['s'] - cur[-1]['e'] > 0.6):
            chunks.append(cur)
            cur = []
        cur.append(w)
    if cur:
        chunks.append(cur)
    for ci, ch in enumerate(chunks):
        nxt = chunks[ci + 1][0]['s'] if ci + 1 < len(chunks) else None
        for i, w in enumerate(ch):
            s = w['s']
            e = ch[i + 1]['s'] if i + 1 < len(ch) else w['e'] + 0.15
            if nxt is not None:
                e = min(e, nxt - 0.01)  # never overlap the next caption chunk
            e = max(e, s + 0.05)
            parts = []
            for j, x in enumerate(ch):
                t = ass_escape(x['w'].upper())
                parts.append(('{\\c&H0033D7FF&}%s{\\c&H00FFFFFF&}' % t) if j == i else t)
            ev.append('Dialogue: 0,%s,%s,Cap,,0,0,0,,{\\pos(%d,%d)}%s' % (ass_time(s), ass_time(e), W // 2, cap_y,
                                                                         '\u2002'.join(parts)))  # en space: clearer gaps with thick outlines
    with open(path, 'w', encoding='utf-8') as f:
        f.write(head + '\n'.join(ev) + '\n')


def parse_box(spec, sw, sh):
    vals = [float(v) for v in spec.split(',')]
    if all(v <= 1.0 for v in vals):
        vals = [vals[0] * sw, vals[1] * sh, vals[2] * sw, vals[3] * sh]
    return tuple(int(v) for v in vals)


def fit_aspect(box, aspect, sw, sh):
    x, y, w, h = box
    cx, cy = x + w / 2, y + h / 2
    if w / h > aspect:
        w = h * aspect
    else:
        h = w / aspect
    x = max(0, min(sw - w, cx - w / 2))
    y = max(0, min(sh - h, cy - h / 2))
    return int(x), int(y), int(w) // 2 * 2, int(h) // 2 * 2


def cmd_render(args):
    need_ffmpeg()
    t0 = time.time()
    work = os.path.abspath(args.work)
    with open(os.path.join(work, 'candidates.json')) as f:
        data = json.load(f)
    meta = data['meta']
    with open(args.picks) as f:
        picks = json.load(f)['clips']
    out_dir = os.path.abspath(args.out or os.path.join(work, 'clips'))
    os.makedirs(out_dir, exist_ok=True)
    model = load_whisper(args.model)
    posts = ['# Ready-to-post clips\n', 'Source: %s (%s)\n' % (meta.get('title'), meta.get('url')),
             'Only post these if you are allowed to clip this streamer. Follow the program\'s credit and tagging rules.\n']
    for n, p in enumerate(picks, 1):
        start, end = float(p['start']), float(p['end'])
        slug = re.sub(r'[^a-z0-9]+', '-', p.get('title', 'clip').lower()).strip('-')[:40] or 'clip'
        name = '%02d-%s' % (n, slug)
        log('Clip %d: %s (%s to %s)' % (n, p.get('title'), hhmmss(start), hhmmss(end)))
        src = os.path.join(work, name + '-source.mp4')
        fetch_section(meta, start, end, src)
        sw, sh = probe_size(src)
        clip_len = probe_duration(src)
        box = None
        if args.facecam == 'auto':
            box = detect_facecam(src, sw, sh, os.path.join(out_dir, name + '-facecam-check.jpg'))
            log('  Facecam %s.' % ('found at %s' % (box,) if box else 'not found, using the full-frame layout'))
        elif args.facecam != 'none':
            box = parse_box(args.facecam, sw, sh)
        layout = 'facecam' if box else 'full'
        wav = os.path.join(work, name + '.wav')
        run(['ffmpeg', '-y', '-v', 'error', '-i', src, '-vn', '-ac', '1', '-ar', '16000', wav])
        _, words = transcribe(model, wav)
        os.remove(wav)
        ass = os.path.join(work, name + '.ass')
        build_ass(words, p.get('title', ''), layout, ass, clip_len)
        ass_f = ass.replace('\\', '/').replace(':', '\\:')
        fonts_f = FONTS.replace('\\', '/').replace(':', '\\:')
        if layout == 'facecam':
            cx, cy, cw, chh = fit_aspect(box, W / TOP_H, sw, sh)
            gh = sh
            gw = int(min(sw, gh * W / (H - TOP_H))) // 2 * 2
            gx = (sw - gw) // 2
            if box[0] + box[2] / 2 < sw / 2:
                gx = min(sw - gw, max(gx, box[0] + box[2]))
            else:
                gx = max(0, min(gx, box[0] - gw))
            fc = ('[0:v]crop=%d:%d:%d:%d,scale=%d:%d,setsar=1[top];'
                  '[0:v]crop=%d:%d:%d:0,scale=%d:%d,setsar=1[bot];'
                  '[top][bot]vstack=inputs=2,subtitles=%s:fontsdir=%s[v]') % (
                cw, chh, cx, cy, W, TOP_H, gw, gh, gx, W, H - TOP_H, ass_f, fonts_f)
        else:
            fc = ('[0:v]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,boxblur=24:2,eq=brightness=-0.08[bg];'
                  '[0:v]scale=%d:-2,setsar=1[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2-140,'
                  'subtitles=%s:fontsdir=%s[v]') % (W, H, W, H, W, ass_f, fonts_f)
        out = os.path.join(out_dir, name + '.mp4')
        run(['ffmpeg', '-y', '-v', 'error', '-i', src, '-filter_complex', fc, '-map', '[v]', '-map', '0:a?',
             '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-r', '30', '-pix_fmt', 'yuv420p',
             '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', out])
        if not args.keep_sources:
            os.remove(src)
        tags = ' '.join(p.get('hashtags') or [])
        if is_url(meta.get('source') or ''):
            credit = 'Clip from %s, %s' % (meta.get('channel') or 'the streamer', meta.get('url'))
        else:
            credit = 'Add the creator name and link here (source file: %s)' % os.path.basename(meta.get('source') or '')
        posts.append('\n## %s\n\nFile: clips/%s.mp4\n\nTitle: %s\n\nCaption: %s\n\nHashtags: %s\n\nCredit: %s\n\nWhy this one: %s\n' % (
            name, name, p.get('title', ''), p.get('caption', ''), tags, credit, p.get('reason', '')))
        log('  Saved %s' % out)
    with open(os.path.join(out_dir, 'posts.md'), 'w') as f:
        f.write('\n'.join(posts))
    log('Done: %d clips in %d s. Captions and hashtags are in %s' % (len(picks), time.time() - t0,
                                                                      os.path.join(out_dir, 'posts.md')))


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description='imisofts Stream Clipper')
    sub = ap.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('setup')
    s.set_defaults(fn=cmd_setup)
    s = sub.add_parser('find')
    s.add_argument('query')
    s.add_argument('--max', type=int, default=10)
    s.add_argument('--min-minutes', type=int, default=30)
    s.add_argument('--when', default='week', choices=['today', 'week', 'month', 'any'],
                   help='only videos uploaded today, this week, this month, or any time')
    s.add_argument('--json')
    s.set_defaults(fn=cmd_find)
    s = sub.add_parser('analyze')
    s.add_argument('source', help='stream link or a video file on this computer')
    s.add_argument('--work', required=True)
    s.add_argument('--windows', type=int, default=25, help='how many loud moments to write down')
    s.add_argument('--before', type=float, default=40)
    s.add_argument('--after', type=float, default=20)
    s.add_argument('--model', default='small', help='Whisper size: tiny, base, small, medium')
    s.set_defaults(fn=cmd_analyze)
    s = sub.add_parser('render')
    s.add_argument('--work', required=True)
    s.add_argument('--picks', required=True)
    s.add_argument('--out')
    s.add_argument('--facecam', default='auto', help='auto, none, or x,y,w,h (pixels or 0-1 fractions)')
    s.add_argument('--model', default='small')
    s.add_argument('--keep-sources', action='store_true')
    s.set_defaults(fn=cmd_render)
    args = ap.parse_args()
    args.fn(args)


if __name__ == '__main__':
    main()

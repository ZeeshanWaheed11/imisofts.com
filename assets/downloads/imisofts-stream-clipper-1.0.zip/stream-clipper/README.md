# Stream Clipper (free, by imisofts)

Turn a long stream, like a GTA 6 stream, into ready-to-post vertical clips: facecam on top, gameplay below, word-by-word captions, a title, and a caption with hashtags for every clip.

## What you need

- A computer (Mac, Windows or Linux) with Python 3.9 or newer
- ffmpeg (Mac: `brew install ffmpeg`, Windows: `winget install Gyan.FFmpeg`)
- Claude Code, or another AI coding assistant that can read a skill folder

## Install

**Easiest:** open Claude Code, drag this zip in and type: `install this skill`.

**By hand:** unzip it so the folder sits at `~/.claude/skills/stream-clipper/` (the file `SKILL.md` must be directly inside that folder).

## Use

In Claude Code, type something like:

- `make five clips from this stream: <link>`
- `find today's biggest GTA 6 streams`

Claude checks that you are allowed to clip the stream, runs the tool, picks the best moments with you, and saves the clips plus `posts.md`.

You can also run the steps yourself:

```
python3 scripts/clipper.py setup
python3 scripts/clipper.py find "gta 6 stream"
python3 scripts/clipper.py analyze "<link or file>" --work clipper-work/test
# write clipper-work/test/picks.json (see SKILL.md)
python3 scripts/clipper.py render --work clipper-work/test --picks clipper-work/test/picks.json
```

## Please clip fairly

Only clip streamers who allow it: many run paid clipping programs. Credit them the way the program asks. Don't post story spoilers or cutscene-only clips.

## Licence

MIT for the code. The Inter font in `assets/fonts` is under the SIL Open Font License (see its licence file).

Rockstar's own policy page also matters for GTA clips: it says Take-Two generally doesn't object to non-commercial fan use, that making money from the footage counts as commercial, and that videos can be taken down at any time. Read it before you earn from GTA footage: https://support.rockstargames.com/articles/7bNaeoMFTV0iUDGhStTXvz/policy-on-posting-copyrighted-rockstar-games-material

## Version

1.0 (November 2026). Download page and video guide: https://imisofts.com/stream-clipper

Made by [imisofts](https://imisofts.com). Want clips posted to TikTok, YouTube and Instagram automatically, or a version built for your brand? [Talk to us](https://imisofts.com/ai-automation-agency).
